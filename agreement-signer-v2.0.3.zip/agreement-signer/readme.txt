=== Agreement Signer ===
Requires at least: 5.8
Requires PHP: 7.4 (ZipArchive extension)
Stable tag: 2.0.0
License: GPLv2 or later

Upload any number of Word (.docx) agreements as they are. Visitors fill in the fields inside the document, sign (draw / type / upload) and download a signed PDF. No limit on the number of agreements.

== Quick start ==

1. Plugins -> Add New -> Upload Plugin -> agreement-signer.zip -> Activate.
2. Agreements -> Add Agreement. Enter a title, upload your .docx, click Publish.
3. The agreement is live at /agreements/<title>/ . Or put [agreement_sign id="123"] on any page. [agreement_list] shows links to all agreements.
4. Signed PDFs appear under Agreements -> Signed Agreements and are emailed to you (and to the signer).

== Your Word file needs no special markup ==

Upload the .docx as it is. When a visitor opens the agreement, the fields are found automatically and filled in directly inside the document:

* Table row with a label and an EMPTY cell     -> input box in that cell. Type is guessed from the label: Email, Telephone, Date (calendar picker), amounts (£, %), Address / Notes / Limitations (large text area), otherwise a text box.
* "Goods: ______" lines                         -> input box on that line
* ☐ symbols                                     -> tick boxes; if the text above says "Select one ..." they become radio buttons
* "Signature" row or line                       -> click-to-sign box (Draw / Type / Upload image)
* "Date" row or line                            -> calendar, today by default
* Several signing blocks (Artist + Company)     -> the signer completes the first block; the others are greyed out for the other party (changeable per agreement)
* "Name" row in the first signing block         -> pre-filled from the signer's name
* Required fields: name, email, phone, address, dates, "Select one" choices, signature, and tick boxes under a "confirms ..." sentence. Use the per-agreement "optional" / "required" lists to change this.

Old {{placeholder}} syntax still works if you prefer it (see below), but is no longer needed.
Not supported in the Word file: text boxes, headers and footers (use the body or tables).

Optional placeholder syntax:
{{Full Name}}   {{Email|email}}   {{Package|select|Basic,Pro,Premium}}   {{I agree|checkbox}}   {{Notes?|textarea}}   {{Signature}}   {{Date Signed}}

== Signature methods (per agreement) ==

Draw, Type (5 handwriting styles), Upload (photo/PNG/JPG, white background removed), and Adobe Acrobat Sign.
Adobe: paste an Acrobat Sign "Web Form" link into the agreement. Signing then happens on Adobe's page and Adobe stores the result; it is not stored by this plugin.
Signatures saved from Adobe Acrobat "Fill & Sign" as an image can also be used with the Upload method.

== Server notes ==

* PHP upload limits: set upload_max_filesize and post_max_size to at least 16M (signed PDFs are typically 0.2-3 MB).
* Files live in wp-content/uploads/agreement-signer/ with random names and are only served through WordPress. On Nginx, add: location ~* /uploads/agreement-signer/ { deny all; }
* Exclude agreement pages from full-page caching if possible (a fresh nonce is fetched at submit time, so caching is safe, but it is good practice).
* Deleting the plugin keeps signed records and PDFs (legal records).
* The PDF is rendered in the signer's browser (text is part of an image, not selectable) and includes a signature record page. The server also stores IP, time, browser and the SHA-256 of the agreement file version that was signed.
* A drawn/typed/uploaded signature is a simple electronic signature. Have your solicitor confirm it is sufficient for each agreement type.
