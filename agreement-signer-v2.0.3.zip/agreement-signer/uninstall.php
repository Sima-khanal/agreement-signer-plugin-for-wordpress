<?php
/**
 * Uninstall: remove settings only.
 * Signed agreements and their PDFs are legal records and are deliberately kept.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_option( 'ags_options' );
