<?php
/**
 * Plugin Name:       Agreement Signer
 * Description:       Upload any Word (.docx) agreement as it is. Text boxes, check boxes, radio buttons, tables and dates are detected automatically and filled in directly in the document; visitors sign (draw, type, upload an image, or Adobe Acrobat Sign) and download the signed PDF. Signed copies are stored privately and emailed.
 * Version:           2.0.3
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            The Art Agents
 * License:           GPL-2.0-or-later
 * Text Domain:       agreement-signer
 *
 * @package AgreementSigner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'AGS_VERSION', '2.0.3' );
define( 'AGS_FILE', __FILE__ );
define( 'AGS_DIR', plugin_dir_path( __FILE__ ) );
define( 'AGS_URL', plugin_dir_url( __FILE__ ) );
define( 'AGS_CPT', 'ags_agreement' );   // The agreement templates you upload.
define( 'AGS_CPT_SIGNED', 'ags_signed' ); // Signed records.

require_once AGS_DIR . 'includes/storage.php';
require_once AGS_DIR . 'includes/parser.php';
require_once AGS_DIR . 'includes/post-types.php';
require_once AGS_DIR . 'includes/admin.php';
require_once AGS_DIR . 'includes/frontend.php';
require_once AGS_DIR . 'includes/ajax.php';

function ags_activate() {
	ags_register_post_types();
	ags_storage_dir();
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'ags_activate' );

function ags_deactivate() {
	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'ags_deactivate' );

add_filter(
	'plugin_action_links_' . plugin_basename( __FILE__ ),
	function ( $links ) {
		array_unshift( $links, '<a href="' . esc_url( admin_url( 'edit.php?post_type=' . AGS_CPT ) ) . '">Agreements</a>' );
		return $links;
	}
);

/**
 * Plugin options with defaults.
 */
function ags_get_options() {
	return wp_parse_args(
		get_option( 'ags_options', array() ),
		array(
			'notify_email' => get_option( 'admin_email' ),
			'copy_signer'  => 1,
			'rate_limit'   => 10, // Signings per IP per hour.
		)
	);
}
