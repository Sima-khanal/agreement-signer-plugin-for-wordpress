/* Agreement Signer v2 – front-end.
 * Upload a plain Word file: fields are detected from the document itself and filled in place.
 *   - table row "Label | (empty cell)"    -> input in that cell (type guessed from the label: email, phone, date, number, text area...)
 *   - ☐ boxes                             -> check boxes; after "Select one ..." they become radio buttons
 *   - ______ lines after a label          -> input on that line
 *   - "Signature" row / line              -> click-to-sign box (draw, type or upload)
 *   - "Date" row / line                   -> calendar date picker (today by default)
 *   - {{placeholders}} still work (optional, old syntax)
 */
(function () {
	'use strict';

	var G = window.agsGlobal || {};
	var FONTS = [
		{ name: 'Dancing Script', css: "'AGS Dancing Script'" },
		{ name: 'Great Vibes', css: "'AGS Great Vibes'" },
		{ name: 'Caveat', css: "'AGS Caveat'" },
		{ name: 'Allura', css: "'AGS Allura'" },
		{ name: 'Homemade Apple', css: "'AGS Homemade Apple'" }
	];
	var PH_RE = /\{\{((?:[^{}<]|<[^>]*>)*?)\}\}/g;
	var TOKEN_SRC = '[\\u2610\\u25A1]|\\[\\s\\]|_{3,}';
	var GLYPH_RE = /[☐□]|\[\s\]/;
	var HEAD_RE = /^\d+(\.\d+)*\.?\s+\S/;
	var SELECT_ONE = /\b(select|choose|tick|check|mark|pick)\s+(only\s+)?(one|1)\b/i;
	var CONFIRM = /\bconfirms?\b|\backnowledges?\b/i;
	var SIG_RE = /^signature\b/i;
	var TEXTAREA_RE = /address|limitation|arrangement|already agreed|requirement|variation|exclusion|\bnotes?\b|comments?|details|description|message|reason|principal/;
	var SAVED_KEY = 'ags_saved_signature_v1';

	function esc(s) {
		return String(s).replace(/[&<>"']/g, function (c) {
			return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
		});
	}
	function decode(s) { var t = document.createElement('textarea'); t.innerHTML = s; return t.value; }
	function clean(s) { return String(s || '').replace(/[\s ]+/g, ' ').trim(); }
	function lower(s) { return String(s).toLowerCase(); }
	function fmtDate(d) { return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }); }
	function ymd(d) { var m = d.getMonth() + 1, x = d.getDate(); return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (x < 10 ? '0' : '') + x; }
	function slug(s) { return String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'agreement'; }
	function el(tag, cls, attrs) {
		var e = document.createElement(tag);
		if (cls) { e.className = cls; }
		for (var k in (attrs || {})) { e.setAttribute(k, attrs[k]); }
		return e;
	}
	function cellsOf(tr) { return Array.prototype.filter.call(tr.children, function (c) { return /^t[dh]$/i.test(c.tagName); }); }
	function isBlank(n) { return !clean(n.textContent) && !n.querySelector('[data-ags],.ags-sig-slot,.ags-ph,img'); }
	function lsGet(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } }
	function lsSet(k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* ignore */ } }
	function lsDel(k) { try { window.localStorage.removeItem(k); } catch (e) { /* ignore */ } }

	/** Inject once: beats dark-mode themes on text inputs only (never touch checkbox/radio) */
	function ensureForceCss() {
		if (document.getElementById('ags-force-css')) { return; }
		var s = document.createElement('style');
		s.id = 'ags-force-css';
		s.textContent = [
			'.ags-app{color-scheme:only light!important}',
			/* Text-like inputs only — identical light style, no yellow/green variants */
			'.ags-app input[type=text],.ags-app input[type=email],.ags-app input[type=tel],',
			'.ags-app input[type=date],.ags-app input[type=number],.ags-app input[type=password],',
			'.ags-app textarea,.ags-app select,.ags-app input.ags-in,.ags-app textarea.ags-in,.ags-app select.ags-in{',
			'  color-scheme:only light!important;',
			'  -webkit-appearance:none!important;appearance:none!important;',
			'  background-color:#f4f7fb!important;background-image:none!important;',
			'  box-shadow:inset 0 0 0 9999px #f4f7fb!important;',
			'  color:#1d2330!important;-webkit-text-fill-color:#1d2330!important;',
			'  caret-color:#1d2330!important;border:1px solid #c5cdd8!important;',
			'  border-radius:6px!important;opacity:1!important;filter:none!important',
			'}',
			'.ags-app input[type=text]:focus,.ags-app input[type=email]:focus,.ags-app input[type=tel]:focus,',
			'.ags-app input[type=date]:focus,.ags-app input[type=number]:focus,.ags-app textarea:focus,.ags-app select:focus,',
			'.ags-app input.ags-in:focus,.ags-app textarea.ags-in:focus{',
			'  background-color:#ffffff!important;box-shadow:inset 0 0 0 9999px #ffffff!important;',
			'  border-color:#1f3a5f!important;outline:2px solid #1f3a5f!important;outline-offset:1px',
			'}',
			'.ags-app input.ags-invalid,.ags-app textarea.ags-invalid{',
			'  background-color:#fff5f5!important;box-shadow:inset 0 0 0 9999px #fff5f5!important;border-color:#d93025!important',
			'}',
			'.ags-app input::placeholder,.ags-app textarea::placeholder{',
			'  color:#9aa3b2!important;-webkit-text-fill-color:#9aa3b2!important;opacity:1!important;font-weight:400!important',
			'}',
			/* Checkboxes & radios — keep native visible icons, never appearance:none */
			'.ags-app input[type=checkbox],.ags-app input[type=radio],.ags-app .ags-cb{',
			'  -webkit-appearance:auto!important;appearance:auto!important;',
			'  width:18px!important;height:18px!important;min-width:18px!important;min-height:18px!important;',
			'  margin:0 8px 0 0!important;vertical-align:middle!important;',
			'  accent-color:#1f3a5f!important;cursor:pointer!important;',
			'  background:none!important;box-shadow:none!important;border:none!important;',
			'  opacity:1!important;filter:none!important;color-scheme:light!important',
			'}',
			'.ags-app .ags-doc{color:#1d2330!important;background:#fff!important}',
			'.ags-app .ags-doc p,.ags-app .ags-doc li,.ags-app .ags-doc td,.ags-app .ags-doc th,',
			'.ags-app .ags-doc span,.ags-app .ags-doc div,.ags-app .ags-doc strong,.ags-app .ags-doc em,.ags-app .ags-doc b{',
			'  color:#1d2330!important;-webkit-text-fill-color:#1d2330!important',
			'}',
			'.ags-app .ags-doc a{color:#1f3a5f!important}',
			'.ags-app .ags-doc .ags-blank{color:#6b5a00!important;-webkit-text-fill-color:#6b5a00!important}',
			'.ags-app .ags-doc h1,.ags-app .ags-doc h2,.ags-app .ags-doc h3,.ags-app .ags-doc h4{color:#111!important}'
		].join('\n');
		(document.head || document.documentElement).appendChild(s);
	}

	/** Paint text inputs only — skip checkbox/radio so icons stay visible */
	function paintInput(c, state) {
		if (!c || !c.style) { return; }
		var t = (c.type || '').toLowerCase();
		if (t === 'checkbox' || t === 'radio') { return; }
		/* One identical light style for every text field (no yellow/green variants) */
		var bg = '#f4f7fb', bd = '#c5cdd8', fg = '#1d2330';
		if (state === 'invalid') { bg = '#fff5f5'; bd = '#d93025'; }
		else if (state === 'focus') { bg = '#ffffff'; bd = '#1f3a5f'; }
		c.style.setProperty('color-scheme', 'only light', 'important');
		c.style.setProperty('-webkit-appearance', 'none', 'important');
		c.style.setProperty('appearance', 'none', 'important');
		c.style.setProperty('background-color', bg, 'important');
		c.style.setProperty('background-image', 'none', 'important');
		c.style.setProperty('box-shadow', 'inset 0 0 0 9999px ' + bg, 'important');
		c.style.setProperty('color', fg, 'important');
		c.style.setProperty('-webkit-text-fill-color', fg, 'important');
		c.style.setProperty('caret-color', fg, 'important');
		c.style.setProperty('border', '1px solid ' + bd, 'important');
		c.style.setProperty('filter', 'none', 'important');
		c.style.setProperty('opacity', '1', 'important');
	}

	document.querySelectorAll('.ags-app').forEach(init);

	async function init(root) {
		var cfg;
		try { cfg = JSON.parse(root.getAttribute('data-config')); } catch (e) { return; }
		var started = Date.now();
		try {
			var res = await fetch(G.ajaxUrl + '?action=ags_doc&id=' + cfg.id, { credentials: 'same-origin' });
			if (!res.ok) { throw new Error('load'); }
			var buf = await res.arrayBuffer();
			var out = await window.mammoth.convertToHtml({ arrayBuffer: buf }, { styleMap: ["p[style-name='Title'] => h1.ags-title:fresh", "p[style-name='Subtitle'] => p.ags-subtitle:fresh"] });
			var html = out.value.replace(PH_RE, function (m, inner) {
				if (/<\/?p[\s>]/i.test(inner)) { return m; }
				return '<span class="ags-ph" data-ph="' + esc(decode(inner.replace(/<[^>]*>/g, ''))) + '"></span>';
			});
			new App(root, cfg, html, started);
		} catch (e) {
			root.innerHTML = '<p class="ags-notice">Sorry, this agreement could not be loaded. Please refresh the page or contact us.</p>';
		}
	}

	/* ---------------- canvas helper ---------------- */
	function trimCanvas(src) {
		var w = src.width, h = src.height, ctx = src.getContext('2d');
		var d = ctx.getImageData(0, 0, w, h).data, x0 = w, y0 = h, x1 = -1, y1 = -1, x, y;
		for (y = 0; y < h; y++) {
			for (x = 0; x < w; x++) {
				if (d[(y * w + x) * 4 + 3] > 10) {
					if (x < x0) { x0 = x; } if (x > x1) { x1 = x; }
					if (y < y0) { y0 = y; } if (y > y1) { y1 = y; }
				}
			}
		}
		if (x1 < 0) { return null; }
		var pad = 8, cw = x1 - x0 + 1 + pad * 2, ch = y1 - y0 + 1 + pad * 2;
		var c = document.createElement('canvas');
		c.width = cw; c.height = ch;
		c.getContext('2d').drawImage(src, x0, y0, x1 - x0 + 1, y1 - y0 + 1, pad, pad, x1 - x0 + 1, y1 - y0 + 1);
		return c;
	}

	/* ================= App ================= */
	function App(root, cfg, html, started) {
		var self = this;
		ensureForceCss();
		this.root = root; this.cfg = cfg; this.started = started;
		this.sig = null; this.pending = null; this.done = false;
		this.fields = []; this.sigSlots = []; this.legacy = {}; this.labelCount = {}; this.rn = 0;
		this.uid = 'ags' + cfg.id;
		this.optional = (cfg.optional || []).map(lower);
		this.requiredList = (cfg.required || []).map(lower);

		var id = this.uid;
		root.innerHTML =
			'<div class="ags-wrap">' +
			'<div class="ags-bar"><div class="ags-bar-main"><strong class="ags-prog-txt">&nbsp;</strong><span class="ags-prog"><i></i></span></div>' +
			'<button type="button" class="ags-btn ags-btn-ghost ags-next">Next field &rsaquo;</button></div>' +
			'<div class="ags-who"><div class="ags-field"><label for="' + id + '-name">Your full name <span class="ags-req">*</span></label>' +
			'<input type="text" id="' + id + '-name" name="signer_name" autocomplete="name" maxlength="150"></div>' +
			'<div class="ags-field"><label for="' + id + '-email">Your email <span class="ags-req">*</span></label>' +
			'<input type="email" id="' + id + '-email" name="signer_email" autocomplete="email"><small>Your signed copy is emailed here.</small></div></div>' +
			'<p class="ags-tip">Fill in the highlighted boxes directly in the agreement below, then click the signature box to sign.</p>' +
			'<div class="ags-doc-col"><div class="ags-doc">' + html + '</div></div>' +
			'<form class="ags-final" novalidate>' +
			'<div class="ags-field ags-check ags-consent"><label><input type="checkbox" name="consent"> I have read this agreement and agree to sign it electronically. I understand my electronic signature has the same effect as a handwritten one. <span class="ags-req">*</span></label></div>' +
			'<div class="ags-hp" aria-hidden="true"><label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>' +
			'<div class="ags-actions"><button type="submit" class="ags-btn ags-btn-primary">' + esc(cfg.button) + '</button></div>' +
			'<p class="ags-status" role="status" aria-live="polite"></p></form></div>';
		this.docEl = root.querySelector('.ags-doc');
		this.form = root.querySelector('.ags-final');
		this.nameEl = root.querySelector('[name="signer_name"]');
		this.emailEl = root.querySelector('[name="signer_email"]');
		this.consentEl = root.querySelector('[name="consent"]');

		/* Force light inputs at the top of the form too (dark themes otherwise paint them black) */
		[this.nameEl, this.emailEl].forEach(function (el) {
			if (!el) return;
			paintInput(el, 'plain');
			el.setAttribute('placeholder', el.name === 'signer_name' ? 'Your full name' : 'you@example.com');
		});

		this.detect();
		this.buildModal();
		this.bind();
		this.refresh();
		this.form.addEventListener('submit', function (e) { e.preventDefault(); self.submit(); });
	}

	/* ---------------- detection ---------------- */
	App.prototype.detect = function () {
		var self = this, S = { ctx: '', radio: null, reqChecks: false, sigBlocks: 0, counter: false, party: '' };
		this.legacyPass(S);
		Array.prototype.slice.call(this.docEl.children).forEach(function (b) { self.block(b, S); });
		if (!this.sigSlots.length) {
			var end = el('div', 'ags-sig-end');
			end.innerHTML = '<p class="ags-sig-end-title">Signed by</p>';
			end.appendChild(this.makeSlot());
			this.docEl.appendChild(end);
		}
	};

	App.prototype.block = function (b, S) {
		var tag = b.tagName.toLowerCase(), text = clean(b.textContent);
		if (/^h[1-6]$/.test(tag) || (tag === 'p' && text.length < 90 && HEAD_RE.test(text))) {
			S.ctx = text; S.radio = null; S.reqChecks = false;
		}
		if (tag === 'table') { this.table(b, S); return; }
		if (tag === 'ul' || tag === 'ol') {
			var self = this;
			Array.prototype.forEach.call(b.querySelectorAll('li'), function (li) { self.textBlock(li, S); });
			return;
		}
		this.textBlock(b, S);
	};

	App.prototype.textBlock = function (b, S) {
		var t = clean(b.textContent);
		if (SELECT_ONE.test(t) && !GLYPH_RE.test(t)) { S.radio = { name: this.uid + '-r' + (++this.rn), label: S.ctx || t, field: null }; }
		if (CONFIRM.test(t) && !GLYPH_RE.test(t)) { S.reqChecks = true; }
		this.transformText(b, S);
	};

	/** Replace ☐ and ____ inside a block with real controls. */
	App.prototype.transformText = function (container, S) {
		var self = this, re = new RegExp(TOKEN_SRC, 'g'), nodes = [], n, prefix = '';
		var walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
		while ((n = walker.nextNode())) { nodes.push(n); }
		nodes.forEach(function (node) {
			var s = node.nodeValue;
			re.lastIndex = 0;
			if (!re.test(s)) { prefix += s; return; }
			re.lastIndex = 0;
			var frag = document.createDocumentFragment(), last = 0, m;
			while ((m = re.exec(s))) {
				var before = s.slice(last, m.index);
				if (before) { frag.appendChild(document.createTextNode(before)); prefix += before; }
				last = m.index + m[0].length;
				frag.appendChild(m[0].charAt(0) === '_' ? self.lineField(prefix, S) : self.boxField(container, S));
			}
			var rest = s.slice(last);
			if (rest) { frag.appendChild(document.createTextNode(rest)); prefix += rest; }
			node.parentNode.replaceChild(frag, node);
		});
	};

	App.prototype.optionLabel = function (container) {
		var txt = function (c) {
			var p = c.querySelector('p') || c;
			return clean(p.textContent.replace(new RegExp(TOKEN_SRC, 'g'), ' '));
		};
		var label;
		if (/^t[dh]$/i.test(container.tagName) && cellsOf(container.parentNode).length > 1) {
			label = cellsOf(container.parentNode).map(txt).filter(Boolean).join(' – ');
		} else {
			label = txt(container);
		}
		return label.length > 110 ? label.slice(0, 107) + '…' : (label || 'Option');
	};

	App.prototype.boxField = function (container, S) {
		var label = this.optionLabel(container), input;
		if (S.radio) {
			input = el('input', 'ags-cb ags-rb', { type: 'radio', name: S.radio.name, 'data-ags': '1', 'aria-label': label });
			input.setAttribute('data-opt', label);
			if (!S.radio.field) {
				S.radio.field = this.addField({ key: S.radio.name, label: S.radio.label, type: 'radio', required: true, inputs: [] }, S);
			}
			S.radio.field.inputs.push(input);
			this.markReq(input, true);
		} else {
			input = el('input', 'ags-cb', { type: 'checkbox', 'data-ags': '1', 'aria-label': label });
			var f = this.addField({ key: this.uid + '-c' + (++this.rn), label: label, type: 'checkbox', required: S.reqChecks, inputs: [input] }, S);
			this.markReq(input, f.required);
		}
		return input;
	};

	App.prototype.lineField = function (prefix, S) {
		var label = clean(prefix).replace(/[:：]\s*$/, '') || S.ctx || 'Field';
		var info = this.infer(label, null);
		if (info.type === 'signature') {
			if (S.sigBlocks > 0 && this.cfg.sigMode !== 'all') { return this.counterEl(S); }
			S.sigBlocks++;
			return this.makeSlot();
		}
		return this.newControl(label, info, S, true);
	};

	/** Table: label/value rows, header rows, signature blocks and ☐ rows. */
	App.prototype.table = function (t, S) {
		var self = this, rows = Array.prototype.slice.call(t.rows);
		var hasSig = rows.some(function (r) { var c = cellsOf(r); return c.length > 1 && SIG_RE.test(clean(c[0].textContent)); });
		var isHeader = function (r) {
			var c = cellsOf(r);
			return c.length === 1 && clean(c[0].textContent) && !GLYPH_RE.test(c[0].textContent) && rows.length > 1;
		};
		var hasHeader = rows.some(isHeader);
		if (hasSig && !hasHeader) { this.startBlock(S, ''); }
		rows.forEach(function (r) {
			var c = cellsOf(r);
			if (!c.length) { return; }
			if (hasSig && isHeader(r)) { self.startBlock(S, clean(c[0].textContent)); return; }
			var isLV = c.length >= 2 && !isBlank(c[0]) && !GLYPH_RE.test(c[0].textContent) &&
				c.slice(1).every(isBlank);
			if (isLV) { self.labelValueRow(clean(c[0].textContent), c[c.length - 1], S); return; }
			c.forEach(function (cell) { self.textBlock(cell, S); });
		});
		if (hasSig) { S.counter = false; S.party = ''; }
	};

	App.prototype.startBlock = function (S, party) {
		S.sigBlocks++; S.party = party;
		S.counter = this.cfg.sigMode !== 'all' && S.sigBlocks > 1;
	};

	App.prototype.counterEl = function (S) {
		var s = el('span', 'ags-counter');
		s.textContent = 'To be signed by ' + (S.party || 'the other party');
		return s;
	};

	App.prototype.labelValueRow = function (label, cell, S) {
		var info = this.infer(label, cell);
		if (S.counter) {
			cell.innerHTML = '';
			cell.classList.add('ags-counter-cell');
			if (info.type === 'signature') { cell.appendChild(this.counterEl(S)); }
			return;
		}
		cell.innerHTML = '';
		if (info.type === 'signature') { S.sigBlocksUsed = true; cell.appendChild(this.makeSlot()); return; }
		cell.appendChild(this.newControl(label, info, S, false));
	};

	/** Guess the control type and whether it is required, from the label text. */
	App.prototype.infer = function (label, cell) {
		var l = lower(label), type = 'text';
		if (SIG_RE.test(l)) { type = 'signature'; }
		else if (/e-?mail/.test(l)) { type = 'email'; }
		else if (/\b(tel|telephone|phone|mobile)\b/.test(l)) { type = 'tel'; }
		else if (/\bdate\b|ordered on|received on/.test(l)) { type = 'date'; }
		else if (/company (no|number)|vat\b|registration/.test(l)) { type = 'text'; }
		else if (/£|\$|€|\(%\)|\bamount\b|\bvalue\b|per month/.test(l)) { type = 'number'; }
		else if (TEXTAREA_RE.test(l) || (cell && cell.querySelector('br'))) { type = 'textarea'; }
		var req = /\b(name|e-?mail|telephone|phone|address|position|start date|goods|ordered|date|signature)\b/.test(l) &&
			!/\bif\b|optional|other|trading|legal|website|social|only/.test(l);
		return { type: type, required: req };
	};

	App.prototype.listHit = function (list, label) {
		var l = lower(label);
		return list.some(function (x) { return x && l.indexOf(x) >= 0; });
	};

	App.prototype.makeControl = function (type, label) {
		var c;
		if (type === 'textarea') { c = el('textarea', 'ags-in', { rows: '2', maxlength: '2000' }); }
		else if (type === 'select') { c = el('select', 'ags-in'); }
		else {
			c = el('input', 'ags-in', { type: type === 'text' ? 'text' : type, maxlength: '300' });
			if (type === 'number') { c.setAttribute('step', 'any'); }
			if (type === 'tel') { c.setAttribute('inputmode', 'tel'); }
		}
		c.setAttribute('data-ags', '1');
		c.setAttribute('aria-label', label);
		paintInput(c, 'default');
		/* Light grey placeholder so empty fields stay readable */
		if (type !== 'select' && type !== 'date') {
			c.setAttribute('placeholder', label || 'Type here…');
		}
		return c;
	};

	App.prototype.markReq = function (input, req) { if (req) { input.classList.add('ags-req-in'); } };

	App.prototype.newControl = function (label, info, S, inline) {
		var full = S.party ? S.party + ': ' + label : label, l = lower(label);
		this.labelCount[l + '|' + (S.party || '')] = (this.labelCount[l + '|' + (S.party || '')] || 0) + 1;
		if (this.labelCount[l + '|' + (S.party || '')] > 1 && S.ctx) { full += ' (' + S.ctx.replace(/^\d+(\.\d+)*\.?\s*/, '') + ')'; }
		var c = this.makeControl(info.type, full);
		var req = info.required;
		if (this.listHit(this.optional, label)) { req = false; }
		else if (this.listHit(this.requiredList, label)) { req = true; }
		var f = this.addField({ key: this.uid + '-f' + (++this.rn), label: full, type: info.type, required: req, inputs: [c] }, S);
		this.markReq(c, req);
		if (inline) { c.classList.add('ags-in-line'); }
		if (info.type === 'date' && /^date( signed)?$/.test(l)) { c.value = ymd(new Date()); }
		if (S.sigBlocks === 1 && /^name$/.test(l)) { f.sync = 'name'; }
		if (info.type === 'email' && /^e-?mail( address)?$/.test(l) && !this.syncEmailTaken) { f.sync = 'email'; this.syncEmailTaken = true; }
		return c;
	};

	App.prototype.addField = function (f, S) {
		f.section = S.ctx;
		this.fields.push(f);
		return f;
	};

	App.prototype.makeSlot = function () {
		var s = el('span', 'ags-sig-slot ags-unsigned', { 'data-sig': '1', role: 'button', tabindex: '0', 'aria-label': 'Click to add your signature' });
		this.sigSlots.push(s);
		return s;
	};

	/* Old {{placeholder}} syntax (optional, kept for existing agreements). */
	App.prototype.legacyPass = function (S) {
		var self = this;
		this.docEl.querySelectorAll('.ags-ph').forEach(function (ph) {
			var parts = ph.getAttribute('data-ph').split('|'), label = clean(parts[0]), required = true;
			if (label.slice(-1) === '?') { required = false; label = clean(label.slice(0, -1)); }
			var low = lower(label), key = low.replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
			if (low === 'signature') { ph.parentNode.replaceChild(self.makeSlot(), ph); return; }
			if (low === 'date signed') { var d = el('span', 'ags-val ags-auto-date'); d.textContent = fmtDate(new Date()); ph.parentNode.replaceChild(d, ph); return; }
			if (!key) { return; }
			if (self.legacy[key]) {
				var m = el('span', 'ags-val'); self.legacy[key].mirrors.push(m); ph.parentNode.replaceChild(m, ph); return;
			}
			var type = lower(clean(parts[1] || 'text')), opts = [];
			if (['text', 'email', 'tel', 'date', 'number', 'textarea', 'select', 'checkbox'].indexOf(type) < 0) { type = 'text'; }
			if (type === 'select') {
				opts = parts.slice(2).join('|').split(',').map(clean).filter(Boolean);
				if (!opts.length) { type = 'text'; }
			}
			var c;
			if (type === 'checkbox') { c = el('input', 'ags-cb', { type: 'checkbox', 'data-ags': '1', 'aria-label': label }); }
			else {
				c = self.makeControl(type, label);
				if (type === 'select') {
					c.appendChild(new Option('Choose…', ''));
					opts.forEach(function (o) { c.appendChild(new Option(o, o)); });
				}
			}
			self.markReq(c, required);
			var f = self.addField({ key: self.uid + '-l' + (++self.rn), label: label, type: type, required: required, inputs: [c], mirrors: [] }, S);
			self.legacy[key] = f;
			ph.parentNode.replaceChild(c, ph);
		});
	};

	/* ---------------- values ---------------- */
	App.prototype.value = function (f) {
		if (f.type === 'checkbox') { return f.inputs[0].checked ? 'Yes' : ''; }
		if (f.type === 'radio') {
			var on = f.inputs.filter(function (i) { return i.checked; })[0];
			return on ? on.getAttribute('data-opt') : '';
		}
		return f.inputs[0].value.trim();
	};
	App.prototype.display = function (f) {
		var v = this.value(f);
		if (f.type === 'date' && v) { return fmtDate(new Date(v + 'T00:00:00')); }
		if (f.type === 'checkbox') { return v ? '☑ Yes' : '☐'; }
		return v;
	};
	App.prototype.values = function () {
		var self = this;
		return this.fields.map(function (f) { return { label: f.label, value: self.value(f) }; });
	};

	/* ---------------- progress + refresh ---------------- */
	App.prototype.items = function () {
		var self = this, out = [];
		out.push({ label: 'Your full name', el: this.nameEl, done: !!this.nameEl.value.trim() });
		out.push({ label: 'Your email', el: this.emailEl, done: this.emailEl.value.trim() !== '' && this.emailEl.checkValidity() });
		this.fields.forEach(function (f) {
			if (!f.required) { return; }
			out.push({ label: f.label, el: f.inputs[0], flash: f.inputs[0].closest('td,li,p') || f.inputs[0], done: self.value(f) !== '' });
		});
		out.push({ label: 'Your signature', el: this.sigSlots[0], flash: this.sigSlots[0], done: !!this.sig, isSig: true });
		out.push({ label: 'The agreement box', el: this.consentEl, flash: this.consentEl.closest('.ags-consent'), done: this.consentEl.checked });
		return out;
	};

	App.prototype.refresh = function () {
		var self = this, today = fmtDate(new Date()), nm = this.nameEl.value.trim(), em = this.emailEl.value.trim();
		paintInput(this.nameEl, 'plain');
		paintInput(this.emailEl, 'plain');
		this.fields.forEach(function (f) {
			if (f.sync && !f.touched) {
				var v = f.sync === 'name' ? nm : em;
				if (f.inputs[0].value !== v) { f.inputs[0].value = v; }
			}
			var filled = self.value(f) !== '';
			f.inputs.forEach(function (i) {
				i.classList.toggle('ags-filled', filled);
				if (filled) { i.classList.remove('ags-invalid'); }
				/* Identical style for all text fields; never paint checkbox/radio */
				if (i.classList.contains('ags-in')) {
					paintInput(i, i.classList.contains('ags-invalid') ? 'invalid' : 'default');
				}
			});
			if (f.mirrors) {
				var disp = self.display(f);
				f.mirrors.forEach(function (m) { m.textContent = disp || '[' + f.label + ']'; m.classList.toggle('ags-blank', !disp); });
			}
		});
		this.sigSlots.forEach(function (slot) {
			// Only touch the DOM when the state changed, otherwise a click can be lost mid-way.
			var key = self.sig ? self.sig.dataUrl.length + '|' + nm + '|' + today : '';
			if (slot._key === key) { return; }
			slot._key = key;
			if (self.sig && self.sig.dataUrl) {
				slot.className = 'ags-sig-slot ags-signed';
				slot.innerHTML = '<img src="' + self.sig.dataUrl + '" alt="Signature"><span class="ags-sig-cap">Signed electronically by ' +
					esc(nm || 'signer') + ' on ' + today + '</span><span class="ags-sig-change ags-noprint">Change</span>';
			} else {
				slot.className = 'ags-sig-slot ags-unsigned';
				slot.innerHTML = '<span class="ags-sig-hint">\u270D Click here to sign</span>';
			}
		});
		var items = this.items(), done = items.filter(function (i) { return i.done; }).length;
		this.root.querySelector('.ags-prog-txt').textContent = done === items.length ? 'All done – ready to sign' : done + ' of ' + items.length + ' required items complete';
		this.root.querySelector('.ags-prog i').style.width = Math.round(100 * done / items.length) + '%';
		this.root.querySelector('.ags-next').hidden = done === items.length;
	};

	App.prototype.goTo = function (item) {
		var target = item.flash || item.el;
		if (!target) { return; }
		target.scrollIntoView({ behavior: 'smooth', block: 'center' });
		if (item.el && item.el.focus && !item.isSig) { try { item.el.focus({ preventScroll: true }); } catch (e) { /* ignore */ } }
		target.classList.add('ags-flash');
		setTimeout(function () { target.classList.remove('ags-flash'); }, 1600);
	};

	App.prototype.bind = function () {
		var self = this;
		function onEdit(e) {
			var t = e.target;
			if (t.tagName === 'TEXTAREA' && t.classList.contains('ags-in')) { t.style.height = 'auto'; t.style.height = Math.max(t.scrollHeight + 2, 64) + 'px'; }
			if (e.type === 'input') {
				self.fields.forEach(function (f) { if (f.sync && f.inputs[0] === t) { f.touched = true; } });
			}
			self.refresh();
		}
		this.root.addEventListener('input', onEdit);
		this.root.addEventListener('change', onEdit);
		// Radio buttons: click the selected one again to clear it.
		this.root.addEventListener('pointerdown', function (e) {
			if (e.target.type === 'radio') { e.target.setAttribute('data-was', e.target.checked ? '1' : ''); }
		});
		this.root.addEventListener('click', function (e) {
			var t = e.target;
			if (t.type === 'radio' && t.getAttribute('data-was') === '1') { t.checked = false; t.setAttribute('data-was', ''); self.refresh(); }
			var slot = t.closest && t.closest('.ags-sig-slot');
			if (slot && !self.done) { self.openModal(); }
		});
		this.root.addEventListener('keydown', function (e) {
			if ((e.key === 'Enter' || e.key === ' ') && e.target.classList && e.target.classList.contains('ags-sig-slot') && !self.done) {
				e.preventDefault(); self.openModal();
			}
		});
		this.root.querySelector('.ags-next').addEventListener('click', function () {
			var next = self.items().filter(function (i) { return !i.done; })[0];
			if (next) { self.goTo(next); }
		});
	};

	/* ---------------- signature modal ---------------- */
	App.prototype.buildModal = function () {
		var self = this, m = el('div', 'ags-modal', { role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Add your signature' });
		m.hidden = true;
		m.innerHTML = '<div class="ags-modal-card"><div class="ags-modal-head"><h3>Add your signature</h3>' +
			'<button type="button" class="ags-x" aria-label="Close">&times;</button></div>' +
			'<div class="ags-saved" hidden><span>Saved on this device:</span><img alt="Saved signature"><button type="button" class="ags-btn ags-btn-ghost ags-use-saved">Use it</button>' +
			'<button type="button" class="ags-link ags-forget">Forget</button></div>' +
			'<div class="ags-sigbox"></div>' +
			'<label class="ags-inline ags-remember"><input type="checkbox"> Remember this signature on this device</label>' +
			'<div class="ags-modal-foot"><button type="button" class="ags-btn ags-btn-ghost ags-cancel">Cancel</button>' +
			'<button type="button" class="ags-btn ags-btn-primary ags-apply" disabled>Apply signature</button></div></div>';
		this.root.appendChild(m);
		this.modal = m;
		this.applyBtn = m.querySelector('.ags-apply');
		this.buildSignature(m.querySelector('.ags-sigbox'));
		m.querySelector('.ags-x').addEventListener('click', function () { self.closeModal(); });
		m.querySelector('.ags-cancel').addEventListener('click', function () { self.closeModal(); });
		m.addEventListener('mousedown', function (e) { if (e.target === m) { self.closeModal(); } });
		document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !m.hidden) { self.closeModal(); } });
		this.applyBtn.addEventListener('click', function () {
			if (!self.pending) { return; }
			self.sig = self.pending;
			if (m.querySelector('.ags-remember input').checked) { lsSet(SAVED_KEY, JSON.stringify({ method: self.sig.method, dataUrl: self.sig.dataUrl })); }
			self.closeModal(); self.refresh();
		});
		m.querySelector('.ags-use-saved').addEventListener('click', function () {
			var s = self.savedSig();
			if (s) { self.sig = s; self.closeModal(); self.refresh(); }
		});
		m.querySelector('.ags-forget').addEventListener('click', function () { lsDel(SAVED_KEY); m.querySelector('.ags-saved').hidden = true; });
	};

	App.prototype.savedSig = function () {
		var raw = lsGet(SAVED_KEY);
		if (!raw) { return null; }
		try {
			var s = JSON.parse(raw);
			return s && /^data:image\/png;base64,/.test(s.dataUrl) && ['draw', 'type', 'upload'].indexOf(s.method) >= 0 ? s : null;
		} catch (e) { return null; }
	};

	App.prototype.openModal = function () {
		var s = this.savedSig(), box = this.modal.querySelector('.ags-saved');
		box.hidden = !s;
		if (s) { box.querySelector('img').src = s.dataUrl; }
		this.pending = null; this.applyBtn.disabled = true;
		this.modal.hidden = false;
		document.body.classList.add('ags-modal-open');
		this.resetPanels();
		if (this.padSize) { this.padSize(); }
		if (this.typeSeed) { this.typeSeed(this.nameEl.value.trim()); }
		this.lastFocus = document.activeElement;
		var first = this.modal.querySelector('.ags-tab'); if (first) { first.focus(); }
	};

	App.prototype.closeModal = function () {
		this.modal.hidden = true;
		document.body.classList.remove('ags-modal-open');
		if (this.lastFocus && this.lastFocus.focus) { try { this.lastFocus.focus(); } catch (e) { /* ignore */ } }
	};

	App.prototype.buildSignature = function (box) {
		var self = this, methods = this.cfg.methods;
		var labels = { draw: 'Draw', type: 'Type', upload: 'Upload image', adobe: 'Adobe Sign' };
		var html = '<div class="ags-tabs" role="tablist">';
		methods.forEach(function (m, i) {
			html += '<button type="button" role="tab" class="ags-tab' + (i === 0 ? ' is-on' : '') + '" data-m="' + m + '">' + labels[m] + '</button>';
		});
		html += '</div><div class="ags-panels">';
		methods.forEach(function (m, i) {
			html += '<div class="ags-panel" data-panel="' + m + '"' + (i === 0 ? '' : ' hidden') + '>' + this.panelHtml(m) + '</div>';
		}, this);
		box.innerHTML = html + '</div>';
		this.method = methods[0];

		box.querySelectorAll('.ags-tab').forEach(function (b) {
			b.addEventListener('click', function () {
				box.querySelectorAll('.ags-tab').forEach(function (x) { x.classList.toggle('is-on', x === b); });
				box.querySelectorAll('.ags-panel').forEach(function (p) { p.hidden = p.getAttribute('data-panel') !== b.getAttribute('data-m'); });
				self.method = b.getAttribute('data-m');
				self.pending = null; self.applyBtn.disabled = true;
				self.applyBtn.hidden = self.method === 'adobe';
				self.resetPanels();
				if (self.padSize) { self.padSize(); }
				if (self.method === 'type' && self.typeSeed) { self.typeSeed(self.nameEl.value.trim()); }
			});
		});
		this.applyBtn.hidden = this.method === 'adobe';
		if (methods.indexOf('draw') >= 0) { this.initDraw(box); }
		if (methods.indexOf('type') >= 0) { this.initType(box); }
		if (methods.indexOf('upload') >= 0) { this.initUpload(box); }
	};

	App.prototype.panelHtml = function (m) {
		if (m === 'draw') {
			return '<canvas class="ags-pad" height="180"></canvas>' +
				'<div class="ags-row"><button type="button" class="ags-btn ags-btn-ghost" data-act="undo">Undo</button> ' +
				'<button type="button" class="ags-btn ags-btn-ghost" data-act="clear">Clear</button>' +
				'<span class="ags-inks"><button type="button" class="ags-ink is-on" data-ink="#111111" style="background:#111" aria-label="Black ink"></button>' +
				'<button type="button" class="ags-ink" data-ink="#1a3fa8" style="background:#1a3fa8" aria-label="Blue ink"></button></span></div>' +
				'<small>Sign inside the box using your mouse, finger or stylus.</small>';
		}
		if (m === 'type') {
			var h = '<div class="ags-field"><label>Type your name</label><input type="text" class="ags-type-in" maxlength="60" placeholder="Your full name"></div><div class="ags-styles">';
			FONTS.forEach(function (f, i) {
				h += '<label class="ags-style"><input type="radio" name="ags_font_' + this.uid + '" value="' + i + '"' + (i === 0 ? ' checked' : '') + '><span style="font-family:' + f.css + ',cursive" class="ags-style-prev">Your name</span></label>';
			}, this);
			return h + '</div>';
		}
		if (m === 'upload') {
			return '<div class="ags-field"><label>Signature image (PNG or JPG, up to 5 MB)</label><input type="file" class="ags-file" accept="image/png,image/jpeg,image/webp"></div>' +
				'<label class="ags-inline"><input type="checkbox" class="ags-rmbg" checked> Remove white background</label>' +
				'<canvas class="ags-up-prev" hidden></canvas><small>Tip: sign on white paper, photograph it in good light, and upload the photo. A signature saved from Adobe Acrobat “Fill &amp; Sign” as an image also works.</small>';
		}
		if (m === 'adobe') {
			return '<p>Sign with <strong>Adobe Acrobat Sign</strong>. This opens Adobe’s secure signing page. Adobe will collect your signature and send you the signed copy.</p>' +
				'<p><a class="ags-btn ags-btn-primary" href="' + esc(this.cfg.adobeUrl) + '" target="_blank" rel="noopener noreferrer">Continue with Adobe Sign</a></p>';
		}
		return '';
	};

	App.prototype.resetPanels = function () {
		var box = this.modal.querySelector('.ags-sigbox');
		if (this.padClear) { this.padClear(); }
		var f = box.querySelector('.ags-file'); if (f) { f.value = ''; }
		var p = box.querySelector('.ags-up-prev'); if (p) { p.hidden = true; }
	};

	App.prototype.setSig = function (method, canvas) {
		var t = canvas ? trimCanvas(canvas) : null;
		this.pending = t ? { method: method, dataUrl: t.toDataURL('image/png') } : null;
		this.applyBtn.disabled = !this.pending;
	};

	/* Draw */
	App.prototype.initDraw = function (box) {
		var self = this, cv = box.querySelector('.ags-pad'), ctx, strokes = [], cur = null, ink = '#111111', drawing = false;
		function size() {
			var r = cv.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
			if (!r.width) { return; }
			cv.width = Math.round(r.width * dpr); cv.height = Math.round(180 * dpr);
			ctx = cv.getContext('2d'); ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			redraw();
		}
		function redraw() {
			if (!ctx) { return; }
			ctx.clearRect(0, 0, cv.width, cv.height);
			ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.lineWidth = 2.6;
			strokes.forEach(function (s) {
				ctx.strokeStyle = s.ink; ctx.beginPath();
				s.pts.forEach(function (p, i) { if (i === 0) { ctx.moveTo(p[0], p[1]); } else { ctx.lineTo(p[0], p[1]); } });
				if (s.pts.length === 1) { ctx.lineTo(s.pts[0][0] + 0.1, s.pts[0][1] + 0.1); }
				ctx.stroke();
			});
		}
		function pt(e) { var r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; }
		function commit() { self.setSig('draw', strokes.length ? cv : null); }
		cv.addEventListener('pointerdown', function (e) {
			e.preventDefault(); cv.setPointerCapture(e.pointerId); drawing = true;
			cur = { ink: ink, pts: [pt(e)] }; strokes.push(cur); redraw();
		});
		cv.addEventListener('pointermove', function (e) {
			if (!drawing) { return; } e.preventDefault(); cur.pts.push(pt(e)); redraw();
		});
		function end() { if (drawing) { drawing = false; commit(); } }
		cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
		box.querySelector('[data-act="undo"]').addEventListener('click', function () { strokes.pop(); redraw(); commit(); });
		box.querySelector('[data-act="clear"]').addEventListener('click', function () { strokes = []; redraw(); commit(); });
		box.querySelectorAll('.ags-ink').forEach(function (b) {
			b.addEventListener('click', function () {
				ink = b.getAttribute('data-ink');
				box.querySelectorAll('.ags-ink').forEach(function (x) { x.classList.toggle('is-on', x === b); });
			});
		});
		this.padClear = function () { strokes = []; redraw(); };
		this.padSize = size;
		window.addEventListener('resize', size);
	};

	/* Type */
	App.prototype.initType = function (box) {
		var self = this, panel = box.querySelector('[data-panel="type"]'), inp = panel.querySelector('.ags-type-in'), edited = false;
		function render() {
			var txt = inp.value.trim();
			panel.querySelectorAll('.ags-style-prev').forEach(function (e2) { e2.textContent = txt || 'Your name'; });
			if (!txt) { if (self.method === 'type') { self.setSig('type', null); } return; }
			var idx = +(panel.querySelector('input[type=radio]:checked') || { value: 0 }).value, f = FONTS[idx];
			var fontSpec = '72px ' + f.css;
			(document.fonts ? document.fonts.load(fontSpec, txt) : Promise.resolve()).then(function () {
				var c = document.createElement('canvas'), x = c.getContext('2d');
				x.font = fontSpec; var w = Math.ceil(x.measureText(txt).width) + 60;
				c.width = w; c.height = 140; x = c.getContext('2d');
				x.font = fontSpec; x.fillStyle = '#111'; x.textBaseline = 'middle'; x.fillText(txt, 30, 70);
				if (self.method === 'type') { self.setSig('type', c); }
			});
		}
		this.typeSeed = function (n) {
			if (!edited && inp.value !== n) { inp.value = n; }
			render();
		};
		inp.addEventListener('input', function () { edited = true; render(); });
		panel.querySelectorAll('input[type=radio]').forEach(function (r) { r.addEventListener('change', render); });
	};

	/* Upload */
	App.prototype.initUpload = function (box) {
		var self = this, panel = box.querySelector('[data-panel="upload"]'), file = panel.querySelector('.ags-file'),
			rm = panel.querySelector('.ags-rmbg'), prev = panel.querySelector('.ags-up-prev'), img = null;
		function process() {
			if (!img) { return; }
			var max = 900, sc = Math.min(1, max / img.width), w = Math.round(img.width * sc), h = Math.round(img.height * sc);
			prev.width = w; prev.height = h; prev.hidden = false;
			var ctx = prev.getContext('2d'); ctx.clearRect(0, 0, w, h); ctx.drawImage(img, 0, 0, w, h);
			if (rm.checked) {
				var d = ctx.getImageData(0, 0, w, h), a = d.data;
				for (var i = 0; i < a.length; i += 4) {
					var lum = 0.299 * a[i] + 0.587 * a[i + 1] + 0.114 * a[i + 2];
					var alpha = lum >= 225 ? 0 : (lum <= 150 ? 255 : Math.round(255 * (225 - lum) / 75));
					a[i + 3] = Math.min(a[i + 3], alpha);
					if (alpha > 0) { a[i] = a[i] * 0.4; a[i + 1] = a[i + 1] * 0.4; a[i + 2] = a[i + 2] * 0.4; }
				}
				ctx.putImageData(d, 0, 0);
			}
			self.setSig('upload', prev);
		}
		file.addEventListener('change', function () {
			var f = file.files[0];
			if (!f) { return; }
			if (!/^image\/(png|jpe?g|webp)$/.test(f.type) || f.size > 5 * 1024 * 1024) {
				alert('Please choose a PNG, JPG or WebP image under 5 MB.'); file.value = ''; return;
			}
			var url = URL.createObjectURL(f), im = new Image();
			im.onload = function () { img = im; process(); URL.revokeObjectURL(url); };
			im.onerror = function () { alert('That image could not be read.'); };
			im.src = url;
		});
		rm.addEventListener('change', process);
	};

	/* ---------------- submit ---------------- */
	App.prototype.status = function (msg, isErr) {
		var s = this.form.querySelector('.ags-status');
		s.textContent = msg; s.className = 'ags-status' + (isErr ? ' is-err' : '');
	};

	App.prototype.validate = function () {
		var next = this.items().filter(function (i) { return !i.done; })[0];
		if (next) {
			this.status('Please complete: ' + next.label, true);
			if (next.el && next.el.classList && !next.isSig) { next.el.classList.add('ags-invalid'); }
			this.goTo(next);
			return false;
		}
		var bad = Array.prototype.filter.call(this.docEl.querySelectorAll('input[type=email],input[type=number]'), function (i) { return i.value && !i.checkValidity(); })[0];
		if (bad) {
			this.status('Please check: ' + bad.getAttribute('aria-label'), true);
			bad.classList.add('ags-invalid'); bad.scrollIntoView({ behavior: 'smooth', block: 'center' }); bad.focus({ preventScroll: true });
			return false;
		}
		this.status('');
		return true;
	};

	/** Turn the live document into a static copy for the PDF (inputs become plain text). */
	App.prototype.buildPdfNode = function () {
		var wrap = el('div', 'ags-pdf'), doc = this.docEl.cloneNode(true);
		doc.className = 'ags-doc';
		var live = this.docEl.querySelectorAll('[data-ags]'), copy = doc.querySelectorAll('[data-ags]');
		for (var i = 0; i < live.length; i++) {
			var o = live[i], c = copy[i], span = el('span');
			if (o.type === 'checkbox') { span.className = 'ags-box'; span.textContent = o.checked ? '☑' : '☐'; }
			else if (o.type === 'radio') { span.className = 'ags-box'; span.textContent = o.checked ? '◉' : '○'; }
			else {
				var v = o.value.trim();
				if (o.type === 'date' && v) { v = fmtDate(new Date(v + 'T00:00:00')); }
				span.className = 'ags-val' + (o.tagName === 'TEXTAREA' ? ' ags-val-ml' : '');
				span.textContent = v || ' ';
			}
			c.parentNode.replaceChild(span, c);
		}
		doc.querySelectorAll('.ags-noprint').forEach(function (n) { n.parentNode.removeChild(n); });
		doc.querySelectorAll('.ags-blank').forEach(function (n) { n.textContent = '—'; n.classList.remove('ags-blank'); });
		wrap.appendChild(doc);

		var name = this.nameEl.value.trim(), email = this.emailEl.value.trim(), now = new Date();
		var cert = el('div', 'ags-cert');
		cert.innerHTML = '<h2>Electronic signature record</h2><table>' +
			'<tr><th>Agreement</th><td>' + esc(this.cfg.title) + '</td></tr>' +
			'<tr><th>Signer</th><td>' + esc(name) + ' &lt;' + esc(email) + '&gt;</td></tr>' +
			'<tr><th>Signature method</th><td>' + esc(this.sig.method.charAt(0).toUpperCase() + this.sig.method.slice(1)) + '</td></tr>' +
			'<tr><th>Signed</th><td>' + esc(now.toUTCString()) + '</td></tr>' +
			'<tr><th>Document fingerprint (SHA-256)</th><td class="ags-mono">' + esc(this.cfg.docHash || 'n/a') + '</td></tr>' +
			'<tr><th>Browser</th><td>' + esc(navigator.userAgent) + '</td></tr></table>' +
			'<p>The signer’s IP address and the time of receipt are also recorded by the server that stored this agreement.</p>';
		wrap.appendChild(cert);
		return wrap;
	};

	App.prototype.makePdf = function (node) {
		var opt = {
			margin: [14, 14, 16, 14],
			image: { type: 'jpeg', quality: 0.8 },
			html2canvas: { scale: 1.5, useCORS: true, backgroundColor: '#ffffff', letterRendering: true },
			jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait', compress: true },
			pagebreak: { mode: ['css', 'legacy'], avoid: ['p', 'li', 'tr', 'img', 'h1', 'h2', 'h3', '.ags-sig-end', '.ags-cert', '.ags-sig-slot'] }
		};
		return window.html2pdf().set(opt).from(node).toPdf().get('pdf').then(function (pdf) {
			var n = pdf.internal.getNumberOfPages(), w = pdf.internal.pageSize.getWidth(), h = pdf.internal.pageSize.getHeight();
			for (var i = 1; i <= n; i++) {
				pdf.setPage(i); pdf.setFontSize(8); pdf.setTextColor(130);
				pdf.text('Page ' + i + ' of ' + n, w / 2, h - 7, { align: 'center' });
			}
		}).outputPdf('blob');
	};

	App.prototype.submit = async function () {
		if (this.done || !this.validate()) { return; }
		var btn = this.form.querySelector('.ags-btn-primary[type=submit]');
		btn.disabled = true; this.status('Preparing your signed PDF…');
		var node = this.buildPdfNode();
		// html2pdf measures the source node, so it must be in the page. The wrapper (not the node)
		// is moved off-screen, because html2pdf copies the node's own inline styles into the PDF render.
		var holder = document.createElement('div');
		holder.style.cssText = 'position:fixed;left:-10000px;top:0;width:680px;pointer-events:none;';
		holder.appendChild(node);
		document.body.appendChild(holder);
		var blob;
		try {
			blob = await this.makePdf(node);
		} catch (e) {
			document.body.removeChild(holder);
			btn.disabled = false;
			this.status('Sorry, the PDF could not be created. Please try again.', true); return;
		}
		document.body.removeChild(holder);

		try {
			this.status('Saving your signed agreement…');
			var nres = await (await fetch(G.ajaxUrl + '?action=ags_nonce', { credentials: 'same-origin', cache: 'no-store' })).json();
			var fd = new FormData();
			fd.append('action', 'ags_submit');
			fd.append('nonce', nres.data.nonce);
			fd.append('agreement_id', this.cfg.id);
			fd.append('started', this.started);
			fd.append('website', this.form.querySelector('[name="website"]').value);
			fd.append('signer_name', this.nameEl.value.trim());
			fd.append('signer_email', this.emailEl.value.trim());
			fd.append('method', this.sig.method);
			fd.append('values', JSON.stringify(this.values()));
			fd.append('pdf', blob, 'signed.pdf');
			var res = await fetch(G.ajaxUrl, { method: 'POST', body: fd, credentials: 'same-origin' });
			var json = await res.json();
			if (!json.success) { throw new Error((json.data && json.data.message) || 'Could not save.'); }
		} catch (e) {
			btn.disabled = false;
			this.status((e && e.message) || 'Something went wrong. Please try again.', true);
			return;
		}
		this.finish(blob);
	};

	App.prototype.finish = function (blob) {
		this.done = true;
		var url = URL.createObjectURL(blob), fname = slug(this.cfg.title) + '-signed.pdf', name = this.nameEl.value.trim();
		this.root.classList.add('ags-locked');
		this.root.querySelectorAll('[data-ags],.ags-who input').forEach(function (n) { n.disabled = true; });
		this.root.querySelector('.ags-bar').hidden = true;
		this.form.innerHTML = '<div class="ags-done"><h3>Thank you, ' + esc(name) + '. Your agreement is signed.</h3>' +
			'<p>' + (this.cfg.copySigner ? 'A copy has been emailed to you, and we have saved ours. ' : 'We have saved our copy. ') + 'You can download your signed PDF below.</p>' +
			'<p><a class="ags-btn ags-btn-primary" href="' + url + '" download="' + esc(fname) + '">Download signed PDF</a></p></div>';
		var a = document.createElement('a');
		a.href = url; a.download = fname; document.body.appendChild(a); a.click(); document.body.removeChild(a);
		this.form.scrollIntoView({ behavior: 'smooth', block: 'start' });
	};
})();
