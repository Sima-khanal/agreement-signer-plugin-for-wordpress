<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ags_register_post_types() {
	register_post_type(
		AGS_CPT,
		array(
			'labels'       => array(
				'name'               => 'Agreements',
				'singular_name'      => 'Agreement',
				'add_new'            => 'Add Agreement',
				'add_new_item'       => 'Add New Agreement',
				'edit_item'          => 'Edit Agreement',
				'all_items'          => 'All Agreements',
				'menu_name'          => 'Agreements',
				'not_found'          => 'No agreements yet. Click "Add Agreement" and upload a .docx.',
			),
			'public'       => true,
			'has_archive'  => false,
			'rewrite'      => array( 'slug' => 'agreements' ),
			'menu_icon'    => 'dashicons-media-document',
			'menu_position' => 26,
			'supports'     => array( 'title', 'editor', 'revisions' ),
			'show_in_rest' => false,
		)
	);

	// Signed records: private, admin-only, cannot be created manually.
	register_post_type(
		AGS_CPT_SIGNED,
		array(
			'labels'          => array(
				'name'          => 'Signed Agreements',
				'singular_name' => 'Signed Agreement',
				'menu_name'     => 'Signed Agreements',
				'all_items'     => 'Signed Agreements',
				'edit_item'     => 'Signed Agreement',
				'not_found'     => 'No signed agreements yet.',
			),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => 'edit.php?post_type=' . AGS_CPT,
			'supports'        => array( 'title' ),
			// Standard post capabilities (no custom primitive caps). Only creating by hand is blocked.
			'capabilities'    => array( 'create_posts' => 'do_not_allow' ),
			'map_meta_cap'    => true,
		)
	);
}
add_action( 'init', 'ags_register_post_types' );
