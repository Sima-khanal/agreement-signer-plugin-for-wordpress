<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

foreach ( array( 'ags_doc', 'ags_nonce', 'ags_submit' ) as $a ) {
	add_action( 'wp_ajax_' . $a, 'ags_ajax_' . substr( $a, 4 ) );
	add_action( 'wp_ajax_nopriv_' . $a, 'ags_ajax_' . substr( $a, 4 ) );
}

/** Serve the agreement .docx for a published agreement. */
function ags_ajax_doc() {
	$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
	if ( ! $id || AGS_CPT !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) ) {
		wp_die( 'Not found.', 404 );
	}
	$path = ags_storage_path( get_post_meta( $id, '_ags_file', true ) );
	ags_stream_file( $path, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'agreement.docx', true );
}

/** Fresh nonce at submit time, so full-page caching cannot break signing. */
function ags_ajax_nonce() {
	nocache_headers();
	wp_send_json_success( array( 'nonce' => wp_create_nonce( 'ags_submit' ) ) );
}

function ags_client_ip() {
	return isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
}

function ags_fail( $msg, $code = 400 ) {
	wp_send_json_error( array( 'message' => $msg ), $code );
}

/** Receive the signed PDF + form values. */
function ags_ajax_submit() {
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'ags_submit' ) ) {
		ags_fail( 'Your session expired. Please try again.', 403 );
	}
	// Honeypot + minimum fill time.
	if ( ! empty( $_POST['website'] ) ) {
		ags_fail( 'Could not submit.', 400 );
	}
	$started = isset( $_POST['started'] ) ? (int) $_POST['started'] : 0;
	if ( $started && ( time() - intdiv( $started, 1000 ) ) < 5 ) {
		ags_fail( 'That was too fast. Please review the agreement and try again.' );
	}

	$ip  = ags_client_ip();
	$key = 'ags_rl_' . md5( $ip );
	$n   = (int) get_transient( $key );
	if ( $n >= (int) ags_get_options()['rate_limit'] ) {
		ags_fail( 'Too many submissions from your network. Please try again later.', 429 );
	}

	$id = isset( $_POST['agreement_id'] ) ? (int) $_POST['agreement_id'] : 0;
	if ( ! $id || AGS_CPT !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) ) {
		ags_fail( 'This agreement is not available.', 404 );
	}

	$name  = isset( $_POST['signer_name'] ) ? sanitize_text_field( wp_unslash( $_POST['signer_name'] ) ) : '';
	$email = isset( $_POST['signer_email'] ) ? sanitize_email( wp_unslash( $_POST['signer_email'] ) ) : '';
	if ( strlen( $name ) < 2 || strlen( $name ) > 150 ) {
		ags_fail( 'Please enter your full name.' );
	}
	if ( ! is_email( $email ) ) {
		ags_fail( 'Please enter a valid email address.' );
	}

	$method = isset( $_POST['method'] ) ? sanitize_key( wp_unslash( $_POST['method'] ) ) : '';
	$allowed_methods = get_post_meta( $id, '_ags_methods', true );
	if ( ! is_array( $allowed_methods ) || ! in_array( $method, $allowed_methods, true ) || 'adobe' === $method ) {
		ags_fail( 'That signature method is not allowed.' );
	}

	// Field values are detected in the browser from the Word file, so they are stored as a simple
	// label => value list for the records screen. The signed PDF itself is the legal record.
	$posted = isset( $_POST['values'] ) ? json_decode( wp_unslash( $_POST['values'] ), true ) : array(); // phpcs:ignore WordPress.Security
	$posted = is_array( $posted ) ? array_slice( $posted, 0, 300 ) : array();
	$values = array();
	foreach ( $posted as $row ) {
		if ( ! is_array( $row ) || ! isset( $row['label'] ) || ! isset( $row['value'] ) || ! is_scalar( $row['label'] ) || ! is_scalar( $row['value'] ) ) {
			continue;
		}
		$label = mb_substr( sanitize_text_field( (string) $row['label'] ), 0, 160 );
		$val   = mb_substr( sanitize_textarea_field( (string) $row['value'] ), 0, 2000 );
		if ( '' === $label ) {
			continue;
		}
		$base = $label;
		$n2   = 2;
		while ( isset( $values[ $label ] ) ) {
			$label = $base . ' (' . $n2++ . ')';
		}
		$values[ $label ] = $val;
	}

	// Validate the PDF.
	if ( empty( $_FILES['pdf'] ) || UPLOAD_ERR_OK !== (int) $_FILES['pdf']['error'] ) {
		ags_fail( 'The signed PDF did not upload. Please try again.' );
	}
	$pdf = $_FILES['pdf']; // phpcs:ignore WordPress.Security
	if ( $pdf['size'] < 500 || $pdf['size'] > 25 * MB_IN_BYTES ) {
		ags_fail( 'The signed PDF is empty or too large.' );
	}
	$head = file_get_contents( $pdf['tmp_name'], false, null, 0, 5 );
	if ( '%PDF-' !== $head ) {
		ags_fail( 'The signed file is not a valid PDF.' );
	}

	$stored = ags_random_name( 'pdf' );
	$dest   = ags_storage_dir() . '/' . $stored;
	if ( ! move_uploaded_file( $pdf['tmp_name'], $dest ) ) {
		ags_fail( 'The server could not save the signed PDF.', 500 );
	}

	$title   = get_the_title( $id );
	$now     = gmdate( 'Y-m-d H:i:s' );
	$rec_id  = wp_insert_post(
		array(
			'post_type'   => AGS_CPT_SIGNED,
			'post_status' => 'private',
			'post_title'  => $title . ' — ' . $name . ' — ' . $now . ' UTC',
		)
	);
	if ( ! $rec_id || is_wp_error( $rec_id ) ) {
		wp_delete_file( $dest );
		ags_fail( 'Could not record the signature.', 500 );
	}
	$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 255 ) : '';
	$meta = array(
		'_ags_agreement_id'    => $id,
		'_ags_agreement_title' => $title,
		'_ags_signer_name'     => $name,
		'_ags_signer_email'    => $email,
		'_ags_method'          => $method,
		'_ags_signed_at'       => $now,
		'_ags_ip'              => $ip,
		'_ags_ua'              => $ua,
		'_ags_doc_hash'        => get_post_meta( $id, '_ags_hash', true ),
		'_ags_pdf'             => $stored,
		'_ags_pdf_hash'        => hash_file( 'sha256', $dest ),
		'_ags_values'          => $values,
	);
	foreach ( $meta as $k => $v ) {
		update_post_meta( $rec_id, $k, $v );
	}
	set_transient( $key, $n + 1, HOUR_IN_SECONDS );

	ags_send_emails( $rec_id, $id, $title, $name, $email, $dest );
	wp_send_json_success( array( 'record' => $rec_id ) );
}

function ags_send_emails( $rec_id, $agreement_id, $title, $name, $email, $pdf_path ) {
	$opts   = ags_get_options();
	$notify = get_post_meta( $agreement_id, '_ags_notify', true ) ?: $opts['notify_email'];
	$files  = array( $pdf_path );
	$site   = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

	if ( is_email( $notify ) ) {
		$body = "A new agreement has been signed.\n\nAgreement: $title\nSigner: $name <$email>\nSigned (UTC): " . get_post_meta( $rec_id, '_ags_signed_at', true ) . "\n\nView it: " . admin_url( 'post.php?post=' . $rec_id . '&action=edit' ) . "\nThe signed PDF is attached.";
		wp_mail( $notify, "[$site] Signed: $title — $name", $body, array( 'Reply-To: ' . $name . ' <' . $email . '>' ), $files );
	}
	if ( ! empty( $opts['copy_signer'] ) ) {
		$body = "Hello $name,\n\nThank you for signing \"$title\". Your signed copy is attached for your records.\n\n$site";
		wp_mail( $email, "Your signed copy: $title", $body, array(), $files );
	}
}
