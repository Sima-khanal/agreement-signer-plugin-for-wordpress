<?php
/**
 * Placeholder parsing for .docx agreements.
 *
 * Placeholder syntax (typed straight into the Word file):
 *   {{Full Name}}                       text box
 *   {{Email Address|email}}             email box
 *   {{Start Date|date}}                 date picker
 *   {{Fee|number}}                      number box
 *   {{Phone|tel}}                       phone box
 *   {{Notes?|textarea}}                 multi-line, "?" after the label = optional
 *   {{Package|select|Basic,Pro,Premium}} drop-down
 *   {{I accept the terms|checkbox}}     tick box
 *   {{Signature}}                       where the signature goes
 *   {{Date Signed}}                     auto-filled with today's date
 *
 * The same label used twice is ONE field, filled everywhere it appears.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ags_placeholder_regex() {
	return '/\{\{\s*([^{}|]+?)\s*(?:\|\s*([a-z]+)\s*)?(?:\|\s*([^{}]*?)\s*)?\}\}/i';
}

function ags_allowed_types() {
	return array( 'text', 'email', 'tel', 'date', 'number', 'textarea', 'select', 'checkbox' );
}

/**
 * Parse placeholder text into a list of fields (keeps first-seen order).
 *
 * @param string $text Plain text containing {{...}} placeholders.
 * @return array { fields: array[], has_signature: bool }
 */
function ags_parse_fields( $text ) {
	$fields        = array();
	$has_signature = false;

	if ( ! preg_match_all( ags_placeholder_regex(), $text, $m, PREG_SET_ORDER ) ) {
		return array(
			'fields'        => array(),
			'has_signature' => false,
		);
	}

	foreach ( $m as $hit ) {
		$label    = trim( $hit[1] );
		$required = true;
		if ( '?' === substr( $label, -1 ) ) {
			$required = false;
			$label    = trim( substr( $label, 0, -1 ) );
		}
		$low = strtolower( $label );
		if ( 'signature' === $low ) {
			$has_signature = true;
			continue;
		}
		if ( 'date signed' === $low ) {
			continue;
		}
		$key = ags_field_key( $label );
		if ( '' === $key || isset( $fields[ $key ] ) ) {
			continue;
		}
		$type = isset( $hit[2] ) ? strtolower( $hit[2] ) : 'text';
		if ( ! in_array( $type, ags_allowed_types(), true ) ) {
			$type = 'text';
		}
		$options = array();
		if ( 'select' === $type && ! empty( $hit[3] ) ) {
			$options = array_values( array_filter( array_map( 'trim', explode( ',', $hit[3] ) ), 'strlen' ) );
		}
		if ( 'select' === $type && ! $options ) {
			$type = 'text';
		}
		$fields[ $key ] = array(
			'key'      => $key,
			'label'    => $label,
			'type'     => $type,
			'required' => $required,
			'options'  => $options,
		);
	}

	return array(
		'fields'        => array_values( $fields ),
		'has_signature' => $has_signature,
	);
}

function ags_field_key( $label ) {
	return trim( preg_replace( '/[^a-z0-9]+/', '_', strtolower( $label ) ), '_' );
}

/**
 * Read a .docx and return its text, one line per paragraph / table cell paragraph.
 * Joining runs per paragraph makes placeholders work even when Word splits them across runs.
 *
 * @return string|WP_Error
 */
function ags_docx_text( $path ) {
	if ( ! class_exists( 'ZipArchive' ) ) {
		return new WP_Error( 'ags_zip', 'The PHP ZipArchive extension is required to read .docx files.' );
	}
	$zip = new ZipArchive();
	if ( true !== $zip->open( $path ) ) {
		return new WP_Error( 'ags_zip', 'That file is not a valid .docx document.' );
	}
	$parts = array( 'word/document.xml' ); // Body and tables (headers/footers are not shown to signers).
	$out = '';
	foreach ( $parts as $i => $part ) {
		$xml = $zip->getFromName( $part );
		if ( false === $xml ) {
			if ( 0 === $i ) {
				$zip->close();
				return new WP_Error( 'ags_zip', 'That file is not a valid .docx document.' );
			}
			continue;
		}
		$prev = libxml_use_internal_errors( true );
		$dom  = new DOMDocument();
		// LIBXML_NONET blocks network access; entities are not substituted.
		$ok = $dom->loadXML( $xml, LIBXML_NONET | LIBXML_NOWARNING | LIBXML_NOERROR );
		libxml_use_internal_errors( $prev );
		if ( ! $ok ) {
			continue;
		}
		foreach ( $dom->getElementsByTagName( 'p' ) as $p ) {
			$line = '';
			foreach ( $p->getElementsByTagName( 't' ) as $t ) {
				$line .= $t->textContent;
			}
			$out .= $line . "\n";
		}
	}
	$zip->close();
	return $out;
}
