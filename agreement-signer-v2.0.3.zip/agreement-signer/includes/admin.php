<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------------ */
/* Agreement edit screen: upload .docx + signing options               */
/* ------------------------------------------------------------------ */

add_action(
	'post_edit_form_tag',
	function () {
		global $post;
		if ( $post && AGS_CPT === $post->post_type ) {
			echo ' enctype="multipart/form-data"';
		}
	}
);

add_action(
	'add_meta_boxes',
	function () {
		add_meta_box( 'ags_doc', 'Agreement document (.docx)', 'ags_box_doc', AGS_CPT, 'normal', 'high' );
		add_meta_box( 'ags_opts', 'Signing options', 'ags_box_opts', AGS_CPT, 'normal', 'default' );
		add_meta_box( 'ags_use', 'How to show this agreement', 'ags_box_use', AGS_CPT, 'side', 'default' );
		add_meta_box( 'ags_record', 'Signed record', 'ags_box_record', AGS_CPT_SIGNED, 'normal', 'high' );
	}
);

function ags_default_methods() {
	return array( 'draw', 'type', 'upload' );
}

function ags_box_doc( $post ) {
	wp_nonce_field( 'ags_save_' . $post->ID, 'ags_nonce' );
	$orig   = get_post_meta( $post->ID, '_ags_orig_name', true );
	$fields = get_post_meta( $post->ID, '_ags_fields', true );
	$hasSig = get_post_meta( $post->ID, '_ags_has_signature', true );
	?>
	<p>
		<input type="file" name="ags_docx" accept=".docx,application/vnd.openxmlformats-officedocument.wordprocessingml.document">
		<br><span class="description">Upload a Word <strong>.docx</strong> file (max 10 MB). Uploading a new file replaces the current one; earlier signed copies keep their own PDF.</span>
	</p>
	<?php if ( $orig ) : ?>
		<p><strong>Current file:</strong> <?php echo esc_html( $orig ); ?>
		&nbsp;&middot;&nbsp; <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=ags_download_docx&id=' . $post->ID ), 'ags_docx_' . $post->ID ) ); ?>">Download</a></p>

		<p class="description" style="margin-top:12px"><strong>No placeholders needed.</strong> Fields are detected automatically when a visitor opens the agreement, and are filled in directly inside the document.</p>
	<?php endif; ?>

	<details style="margin-top:14px" <?php echo $orig ? '' : 'open'; ?>>
		<summary><strong>How fields are detected from your Word file</strong></summary>
		<table class="widefat striped" style="max-width:720px;margin-top:8px">
			<tbody>
			<tr><td>Table row: label, then an <strong>empty cell</strong></td><td>Input box in that cell. Type is guessed from the label: Email, Telephone, Date (calendar), amounts (£, %), Address / Notes / Limitations (large text area), otherwise a text box.</td></tr>
			<tr><td><code>____</code> line after a label (<code>Goods: ______</code>)</td><td>Input box on that line</td></tr>
			<tr><td><code>&#9744;</code> check box symbols</td><td>Tick boxes. If the text above says <em>"Select one…"</em> they become radio buttons (one choice).</td></tr>
			<tr><td>A <strong>Signature</strong> row or line</td><td>Click-to-sign box (draw, type or upload an image).</td></tr>
			<tr><td>A <strong>Date</strong> row or line</td><td>Calendar date picker, today by default.</td></tr>
			<tr><td>Several signing blocks (e.g. Artist + Company)</td><td>By default only the first block is completed by the signer. Change this under "Signature blocks" on the right.</td></tr>
			<tr><td>Name row in the first signing block</td><td>Pre-filled from the signer's name.</td></tr>
			</tbody>
		</table>
		<p class="description">Optional: the old <code>{{Full Name}}</code>, <code>{{Package|select|A,B}}</code> placeholders still work. Text boxes, headers and footers of the Word file are not shown to signers; use the body or tables.</p>
	</details>
	<?php
}

function ags_box_opts( $post ) {
	$methods = get_post_meta( $post->ID, '_ags_methods', true );
	if ( ! is_array( $methods ) ) {
		$methods = ags_default_methods();
	}
	$adobe  = get_post_meta( $post->ID, '_ags_adobe_url', true );
	$notify = get_post_meta( $post->ID, '_ags_notify', true );
	$button = get_post_meta( $post->ID, '_ags_button', true );
	$sigmode = get_post_meta( $post->ID, '_ags_sigmode', true ) ?: 'first';
	$opt_lbl = get_post_meta( $post->ID, '_ags_optional', true );
	$req_lbl = get_post_meta( $post->ID, '_ags_required', true );
	$all    = array(
		'draw'   => 'Draw with mouse / finger',
		'type'   => 'Type name (choose a handwriting style)',
		'upload' => 'Upload a signature image',
		'adobe'  => 'Adobe Acrobat Sign (needs the web form link below)',
	);
	?>
	<p><strong>Signature methods offered</strong></p>
	<?php foreach ( $all as $k => $label ) : ?>
		<label style="display:block;margin:3px 0"><input type="checkbox" name="ags_methods[]" value="<?php echo esc_attr( $k ); ?>" <?php checked( in_array( $k, $methods, true ) ); ?>> <?php echo esc_html( $label ); ?></label>
	<?php endforeach; ?>

	<p style="margin-top:14px"><label for="ags_adobe"><strong>Adobe Acrobat Sign web form link</strong></label><br>
	<input type="url" id="ags_adobe" name="ags_adobe_url" value="<?php echo esc_attr( $adobe ); ?>" class="large-text" placeholder="https://secure.na1.adobesign.com/public/esignWidget?wid=...">
	<span class="description">In Adobe Acrobat Sign: Send → Publish a Web Form → copy the link. Signing then happens on Adobe's page, so it is stored and downloaded by Adobe, not by this plugin.</span></p>

	<p><label for="ags_notify"><strong>Send signed copies to</strong></label><br>
	<input type="email" id="ags_notify" name="ags_notify" value="<?php echo esc_attr( $notify ); ?>" class="regular-text" placeholder="<?php echo esc_attr( ags_get_options()['notify_email'] ); ?>">
	<span class="description">Leave empty to use the default in Agreements → Settings.</span></p>

	<p><label for="ags_button"><strong>Submit button text</strong></label><br>
	<input type="text" id="ags_button" name="ags_button" value="<?php echo esc_attr( $button ); ?>" class="regular-text" placeholder="Sign &amp; download PDF"></p>

	<p><label for="ags_sigmode"><strong>Signature blocks</strong></label><br>
	<select id="ags_sigmode" name="ags_sigmode">
		<option value="first" <?php selected( $sigmode, 'first' ); ?>>Signer completes the first block only (others are left for the other party)</option>
		<option value="all" <?php selected( $sigmode, 'all' ); ?>>Signer completes every signing block</option>
	</select></p>

	<p><label for="ags_optional"><strong>Fields that are optional</strong></label><br>
	<textarea id="ags_optional" name="ags_optional" rows="3" class="large-text" placeholder="One per line, e.g. Position / Capacity"><?php echo esc_textarea( $opt_lbl ); ?></textarea>
	<span class="description">Any field whose label contains one of these words is not required.</span></p>

	<p><label for="ags_required"><strong>Fields that are required</strong></label><br>
	<textarea id="ags_required" name="ags_required" rows="3" class="large-text" placeholder="One per line, e.g. Website"><?php echo esc_textarea( $req_lbl ); ?></textarea>
	<span class="description">Fields are required by default for name, email, phone, address, dates and the "Select one" choices. Add labels here to make others required.</span></p>
	<?php
}

function ags_box_use( $post ) {
	if ( 'publish' !== $post->post_status ) {
		echo '<p>Publish this agreement to get its page link and shortcode.</p>';
		return;
	}
	echo '<p><strong>Its own page</strong><br><a href="' . esc_url( get_permalink( $post ) ) . '" target="_blank">' . esc_html( get_permalink( $post ) ) . '</a></p>';
	echo '<p><strong>On any page</strong><br><code>[agreement_sign id="' . (int) $post->ID . '"]</code></p>';
	echo '<p><strong>List of all agreements</strong><br><code>[agreement_list]</code></p>';
}

add_action(
	'save_post_' . AGS_CPT,
	function ( $post_id, $post ) {
		if ( ! isset( $_POST['ags_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ags_nonce'] ) ), 'ags_save_' . $post_id ) ) {
			return;
		}
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$allowed = array( 'draw', 'type', 'upload', 'adobe' );
		$methods = isset( $_POST['ags_methods'] ) ? array_values( array_intersect( $allowed, array_map( 'sanitize_key', (array) wp_unslash( $_POST['ags_methods'] ) ) ) ) : array();
		update_post_meta( $post_id, '_ags_methods', $methods );
		update_post_meta( $post_id, '_ags_adobe_url', isset( $_POST['ags_adobe_url'] ) ? esc_url_raw( wp_unslash( $_POST['ags_adobe_url'] ) ) : '' );
		update_post_meta( $post_id, '_ags_notify', isset( $_POST['ags_notify'] ) ? sanitize_email( wp_unslash( $_POST['ags_notify'] ) ) : '' );
		update_post_meta( $post_id, '_ags_button', isset( $_POST['ags_button'] ) ? sanitize_text_field( wp_unslash( $_POST['ags_button'] ) ) : '' );
		update_post_meta( $post_id, '_ags_sigmode', ( isset( $_POST['ags_sigmode'] ) && 'all' === $_POST['ags_sigmode'] ) ? 'all' : 'first' );
		update_post_meta( $post_id, '_ags_optional', isset( $_POST['ags_optional'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ags_optional'] ) ) : '' );
		update_post_meta( $post_id, '_ags_required', isset( $_POST['ags_required'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ags_required'] ) ) : '' );

		if ( ! empty( $_FILES['ags_docx']['name'] ) && UPLOAD_ERR_OK === (int) $_FILES['ags_docx']['error'] ) {
			$err = ags_handle_docx_upload( $post_id, $_FILES['ags_docx'] ); // phpcs:ignore WordPress.Security
			if ( is_wp_error( $err ) ) {
				set_transient( 'ags_notice_' . get_current_user_id(), $err->get_error_message(), 60 );
			}
		}
	},
	10,
	2
);

function ags_handle_docx_upload( $post_id, $file ) {
	$name = sanitize_file_name( $file['name'] );
	if ( 'docx' !== strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) ) {
		return new WP_Error( 'ags_ext', 'Only .docx files are supported. Please save your document as .docx from Word or Google Docs (File → Download → Microsoft Word).' );
	}
	if ( $file['size'] > 10 * MB_IN_BYTES ) {
		return new WP_Error( 'ags_size', 'That file is larger than 10 MB.' );
	}
	$text = ags_docx_text( $file['tmp_name'] );
	if ( is_wp_error( $text ) ) {
		return $text;
	}
	$stored = ags_random_name( 'docx' );
	$dest   = ags_storage_dir() . '/' . $stored;
	if ( ! move_uploaded_file( $file['tmp_name'], $dest ) ) {
		return new WP_Error( 'ags_move', 'Could not save the file. Check that wp-content/uploads is writable.' );
	}

	$old = get_post_meta( $post_id, '_ags_file', true );
	if ( $old ) {
		$p = ags_storage_path( $old );
		if ( $p ) {
			wp_delete_file( $p );
		}
	}
	$parsed = ags_parse_fields( $text );
	update_post_meta( $post_id, '_ags_file', $stored );
	update_post_meta( $post_id, '_ags_orig_name', $name );
	update_post_meta( $post_id, '_ags_hash', hash_file( 'sha256', $dest ) );
	update_post_meta( $post_id, '_ags_fields', $parsed['fields'] );
	update_post_meta( $post_id, '_ags_has_signature', $parsed['has_signature'] ? 1 : 0 );
	return true;
}

add_action(
	'admin_notices',
	function () {
		$msg = get_transient( 'ags_notice_' . get_current_user_id() );
		if ( $msg ) {
			delete_transient( 'ags_notice_' . get_current_user_id() );
			echo '<div class="notice notice-error"><p><strong>Agreement upload failed:</strong> ' . esc_html( $msg ) . '</p></div>';
		}
	}
);

// Admin-only download of the original .docx.
add_action(
	'admin_post_ags_download_docx',
	function () {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'ags_docx_' . $id );
		if ( ! current_user_can( 'edit_post', $id ) ) {
			wp_die( 'Not allowed.', 403 );
		}
		ags_stream_file( ags_storage_path( get_post_meta( $id, '_ags_file', true ) ), 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', get_post_meta( $id, '_ags_orig_name', true ) ?: 'agreement.docx' );
	}
);

/* ------------------------------------------------------------------ */
/* List table columns                                                  */
/* ------------------------------------------------------------------ */

add_filter(
	'manage_' . AGS_CPT . '_posts_columns',
	function ( $cols ) {
		return array(
			'cb'        => $cols['cb'],
			'title'     => 'Agreement',
			'ags_file'  => 'Document',
			'ags_short' => 'Shortcode',
			'ags_count' => 'Signed',
			'date'      => 'Date',
		);
	}
);
add_action(
	'manage_' . AGS_CPT . '_posts_custom_column',
	function ( $col, $id ) {
		if ( 'ags_file' === $col ) {
			$n = get_post_meta( $id, '_ags_orig_name', true );
			echo $n ? esc_html( $n ) : '<em style="color:#b32d2e">No file uploaded</em>';
		} elseif ( 'ags_short' === $col ) {
			echo '<code>[agreement_sign id="' . (int) $id . '"]</code>';
		} elseif ( 'ags_count' === $col ) {
			$q = new WP_Query(
				array(
					'post_type'      => AGS_CPT_SIGNED,
					'post_status'    => 'any',
					'meta_key'       => '_ags_agreement_id',
					'meta_value'     => $id,
					'fields'         => 'ids',
					'posts_per_page' => 1,
					'no_found_rows'  => false,
				)
			);
			echo (int) $q->found_posts;
		}
	},
	10,
	2
);

add_filter(
	'manage_' . AGS_CPT_SIGNED . '_posts_columns',
	function () {
		return array(
			'cb'         => '<input type="checkbox">',
			'title'      => 'Record',
			'ags_agr'    => 'Agreement',
			'ags_signer' => 'Signer',
			'ags_email'  => 'Email',
			'ags_method' => 'Method',
			'date'       => 'Signed',
			'ags_pdf'    => 'PDF',
		);
	}
);
add_action(
	'manage_' . AGS_CPT_SIGNED . '_posts_custom_column',
	function ( $col, $id ) {
		switch ( $col ) {
			case 'ags_agr':
				echo esc_html( get_post_meta( $id, '_ags_agreement_title', true ) );
				break;
			case 'ags_signer':
				echo esc_html( get_post_meta( $id, '_ags_signer_name', true ) );
				break;
			case 'ags_email':
				echo esc_html( get_post_meta( $id, '_ags_signer_email', true ) );
				break;
			case 'ags_method':
				echo esc_html( ucfirst( (string) get_post_meta( $id, '_ags_method', true ) ) );
				break;
			case 'ags_pdf':
				echo '<a class="button button-small" href="' . esc_url( ags_pdf_url( $id ) ) . '">Download PDF</a>';
				break;
		}
	},
	10,
	2
);

function ags_pdf_url( $id ) {
	return wp_nonce_url( admin_url( 'admin-post.php?action=ags_download_pdf&id=' . (int) $id ), 'ags_pdf_' . (int) $id );
}

add_action(
	'admin_post_ags_download_pdf',
	function () {
		$id = isset( $_GET['id'] ) ? (int) $_GET['id'] : 0;
		check_admin_referer( 'ags_pdf_' . $id );
		if ( ! current_user_can( 'manage_options' ) || AGS_CPT_SIGNED !== get_post_type( $id ) ) {
			wp_die( 'Not allowed.', 403 );
		}
		$name = sanitize_title( get_post_meta( $id, '_ags_agreement_title', true ) . '-' . get_post_meta( $id, '_ags_signer_name', true ) ) . '-signed.pdf';
		ags_stream_file( ags_storage_path( get_post_meta( $id, '_ags_pdf', true ) ), 'application/pdf', $name );
	}
);

function ags_box_record( $post ) {
	$g   = function ( $k ) use ( $post ) {
		return get_post_meta( $post->ID, $k, true );
	};
	$rows = array(
		'Agreement'        => $g( '_ags_agreement_title' ),
		'Signer'           => $g( '_ags_signer_name' ),
		'Email'            => $g( '_ags_signer_email' ),
		'Signature method' => ucfirst( (string) $g( '_ags_method' ) ),
		'Signed at (UTC)'  => $g( '_ags_signed_at' ),
		'IP address'       => $g( '_ags_ip' ),
		'Browser'          => $g( '_ags_ua' ),
		'Document SHA-256' => $g( '_ags_doc_hash' ),
		'PDF SHA-256'      => $g( '_ags_pdf_hash' ),
	);
	echo '<table class="widefat striped"><tbody>';
	foreach ( $rows as $k => $v ) {
		echo '<tr><th style="width:180px">' . esc_html( $k ) . '</th><td>' . esc_html( (string) $v ) . '</td></tr>';
	}
	$fields = $g( '_ags_values' );
	if ( is_array( $fields ) ) {
		foreach ( $fields as $label => $v ) {
			echo '<tr><th>' . esc_html( $label ) . '</th><td>' . esc_html( (string) $v ) . '</td></tr>';
		}
	}
	echo '</tbody></table><p><a class="button button-primary" href="' . esc_url( ags_pdf_url( $post->ID ) ) . '">Download signed PDF</a></p>';
}

/* ------------------------------------------------------------------ */
/* Settings                                                            */
/* ------------------------------------------------------------------ */

add_action(
	'admin_menu',
	function () {
		add_submenu_page( 'edit.php?post_type=' . AGS_CPT, 'Agreement Settings', 'Settings', 'manage_options', 'ags-settings', 'ags_settings_page' );
	}
);
add_action(
	'admin_init',
	function () {
		register_setting(
			'ags_settings',
			'ags_options',
			array(
				'sanitize_callback' => function ( $in ) {
					return array(
						'notify_email' => sanitize_email( $in['notify_email'] ?? '' ),
						'copy_signer'  => empty( $in['copy_signer'] ) ? 0 : 1,
						'rate_limit'   => max( 1, min( 200, (int) ( $in['rate_limit'] ?? 10 ) ) ),
					);
				},
			)
		);
	}
);

function ags_settings_page() {
	$o = ags_get_options();
	?>
	<div class="wrap">
		<h1>Agreement Settings</h1>
		<form method="post" action="options.php">
			<?php settings_fields( 'ags_settings' ); ?>
			<table class="form-table">
				<tr><th><label for="ne">Send signed agreements to</label></th>
					<td><input type="email" id="ne" name="ags_options[notify_email]" value="<?php echo esc_attr( $o['notify_email'] ); ?>" class="regular-text"></td></tr>
				<tr><th>Copy to the signer</th>
					<td><label><input type="checkbox" name="ags_options[copy_signer]" value="1" <?php checked( $o['copy_signer'] ); ?>> Email the signer their signed PDF</label></td></tr>
				<tr><th><label for="rl">Spam limit</label></th>
					<td><input type="number" id="rl" min="1" max="200" name="ags_options[rate_limit]" value="<?php echo (int) $o['rate_limit']; ?>" class="small-text"> signings per IP address per hour</td></tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}
