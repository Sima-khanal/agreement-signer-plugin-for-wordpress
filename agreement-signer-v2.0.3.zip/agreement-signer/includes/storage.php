<?php
/**
 * Private file storage (wp-content/uploads/agreement-signer).
 * Files get random names and are only served through PHP handlers.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function ags_storage_dir() {
	$up  = wp_upload_dir();
	$dir = trailingslashit( $up['basedir'] ) . 'agreement-signer';
	if ( ! is_dir( $dir ) ) {
		wp_mkdir_p( $dir );
	}
	if ( is_dir( $dir ) ) {
		if ( ! file_exists( $dir . '/.htaccess' ) ) {
			file_put_contents( $dir . '/.htaccess', "Require all denied\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" );
		}
		if ( ! file_exists( $dir . '/index.php' ) ) {
			file_put_contents( $dir . '/index.php', "<?php // Silence is golden.\n" );
		}
	}
	return $dir;
}

/**
 * Resolve a stored file name to a full path (basename only, so no traversal).
 */
function ags_storage_path( $name ) {
	$name = basename( (string) $name );
	if ( '' === $name ) {
		return '';
	}
	$path = ags_storage_dir() . '/' . $name;
	return file_exists( $path ) ? $path : '';
}

function ags_random_name( $ext ) {
	return wp_generate_password( 32, false, false ) . '.' . $ext;
}

/**
 * Stream a stored file to the browser.
 */
function ags_stream_file( $path, $mime, $download_name, $inline = false ) {
	if ( ! $path || ! is_readable( $path ) ) {
		wp_die( 'File not found.', 404 );
	}
	while ( ob_get_level() ) {
		ob_end_clean();
	}
	nocache_headers();
	header( 'Content-Type: ' . $mime );
	header( 'Content-Length: ' . filesize( $path ) );
	header( 'Content-Disposition: ' . ( $inline ? 'inline' : 'attachment' ) . '; filename="' . sanitize_file_name( $download_name ) . '"' );
	header( 'X-Content-Type-Options: nosniff' );
	readfile( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions
	exit;
}
