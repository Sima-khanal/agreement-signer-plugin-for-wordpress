<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_shortcode( 'agreement_sign', 'ags_shortcode_sign' );
add_shortcode( 'agreement_list', 'ags_shortcode_list' );

function ags_enqueue_assets() {
	static $done = false;
	if ( $done ) {
		return;
	}
	$done = true;
	wp_enqueue_style( 'ags', AGS_URL . 'assets/css/signer.css', array(), AGS_VERSION );
	wp_enqueue_script( 'ags-mammoth', AGS_URL . 'assets/vendor/mammoth.browser.min.js', array(), '1.8.0', true );
	wp_enqueue_script( 'ags-html2pdf', AGS_URL . 'assets/vendor/html2pdf.bundle.min.js', array(), '0.10.2', true );
	wp_enqueue_script( 'ags', AGS_URL . 'assets/js/signer.js', array( 'ags-mammoth', 'ags-html2pdf' ), AGS_VERSION, true );
	wp_localize_script(
		'ags',
		'agsGlobal',
		array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'fontsUrl' => AGS_URL . 'assets/fonts/',
		)
	);
}

/** Split a textarea setting into a clean list of lines. */
function ags_lines( $text ) {
	$out = array();
	foreach ( preg_split( '/[\r\n,]+/', (string) $text ) as $l ) {
		$l = trim( $l );
		if ( '' !== $l ) {
			$out[] = $l;
		}
	}
	return array_slice( $out, 0, 100 );
}

/**
 * Render one agreement signing app.
 */
function ags_render_app( $id ) {
	$id   = (int) $id;
	$post = get_post( $id );
	if ( ! $post || AGS_CPT !== $post->post_type || 'publish' !== $post->post_status ) {
		return '<p class="ags-notice">This agreement is not available.</p>';
	}
	if ( ! get_post_meta( $id, '_ags_file', true ) ) {
		return '<p class="ags-notice">This agreement has no document yet.</p>';
	}
	ags_enqueue_assets();

	$methods = get_post_meta( $id, '_ags_methods', true );
	if ( ! is_array( $methods ) ) {
		$methods = ags_default_methods();
	}
	$adobe = get_post_meta( $id, '_ags_adobe_url', true );
	if ( ! $adobe ) {
		$methods = array_values( array_diff( $methods, array( 'adobe' ) ) );
	}
	if ( ! $methods ) {
		return '<p class="ags-notice">No signature method is enabled for this agreement.</p>';
	}

	$config = array(
		'id'        => $id,
		'title'     => get_the_title( $id ),
		'methods'   => $methods,
		'adobeUrl'  => $adobe,
		'button'    => get_post_meta( $id, '_ags_button', true ) ?: 'Sign & download PDF',
		'docHash'   => get_post_meta( $id, '_ags_hash', true ),
		'copySigner' => (bool) ags_get_options()['copy_signer'],
		'sigMode'   => 'all' === get_post_meta( $id, '_ags_sigmode', true ) ? 'all' : 'first',
		'optional'  => ags_lines( get_post_meta( $id, '_ags_optional', true ) ),
		'required'  => ags_lines( get_post_meta( $id, '_ags_required', true ) ),
	);
	return '<div class="ags-app" data-config="' . esc_attr( wp_json_encode( $config ) ) . '"><p class="ags-loading">Loading agreement&hellip;</p></div>';
}

function ags_shortcode_sign( $atts ) {
	$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'agreement_sign' );
	return ags_render_app( $atts['id'] );
}

function ags_shortcode_list( $atts ) {
	$q = new WP_Query(
		array(
			'post_type'      => AGS_CPT,
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'no_found_rows'  => true,
		)
	);
	if ( ! $q->have_posts() ) {
		return '<p>No agreements available.</p>';
	}
	ags_enqueue_assets();
	$out = '<ul class="ags-list">';
	while ( $q->have_posts() ) {
		$q->the_post();
		$out .= '<li><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></li>';
	}
	wp_reset_postdata();
	return $out . '</ul>';
}

/**
 * Each agreement gets its own page (/agreements/<slug>/) that shows the signing app below any intro text.
 */
add_filter(
	'the_content',
	function ( $content ) {
		if ( is_singular( AGS_CPT ) && in_the_loop() && is_main_query() ) {
			return $content . ags_render_app( get_the_ID() );
		}
		return $content;
	}
);
